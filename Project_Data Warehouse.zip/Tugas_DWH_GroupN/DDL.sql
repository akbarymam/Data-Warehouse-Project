USE groupn_dwh;

CREATE TABLE transaksi (
    TransaksiID VARCHAR(10) PRIMARY KEY,
    HistoriID VARCHAR(20),
    AkunID VARCHAR(15),
    NasabahID VARCHAR(10),
    AplikasiID VARCHAR(10),
    Tipe_Transaksi ENUM('debit', 'kredit'),
    `Jumlah_Transaksi (Rp)` VARCHAR(10),
    Waktu DATETIME,
    `Biaya_Admin (Rp)` VARCHAR(10),
    `Saldo (Rp)` VARCHAR(10),
    `Diskon (%)` VARCHAR(10),
    `Tax (Rp)` VARCHAR(10),
    FOREIGN KEY (HistoriID) REFERENCES histori(HistoriID),
    FOREIGN KEY (AkunID) REFERENCES akun_bank(AkunID),
    FOREIGN KEY (NasabahID) REFERENCES nasabah(NasabahID),
    FOREIGN KEY (AplikasiID) REFERENCES aplikasi(AplikasiID)
);

CREATE TABLE nasabah (
    NasabahID VARCHAR(10) PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Address TEXT,
    PhoneNumber VARCHAR(15),
    Status_pengajuan ENUM('disetujui', 'tidak disetujui')
);

CREATE TABLE aplikasi (
    AplikasiID VARCHAR(10) PRIMARY KEY,
    Nama_Nasabah VARCHAR(100),
    Email VARCHAR(100),
    Pass VARCHAR(50),
    MobileNumber VARCHAR(15)
);

CREATE TABLE akun_bank (
    AkunID VARCHAR(15) PRIMARY KEY,
    Nama_Nasabah VARCHAR(100),
    `Saldo (Rp)` VARCHAR(10)
);

CREATE TABLE histori (
    HistoriID VARCHAR(10) PRIMARY KEY,
    AkunID VARCHAR(15),
    Deskripsi VARCHAR(50),
    Waktu DATETIME
);










