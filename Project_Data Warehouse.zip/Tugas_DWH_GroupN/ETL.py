import pandas as pd
import numpy as np
import mysql.connector
from mysql.connector import Error

# Fungsi untuk membuat koneksi MySQL (extract)
def create_connection(host_name, user_name, user_password, db_name):
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            passwd=user_password,
            database=db_name
        )
        print("Koneksi Database MySQL berhasil")
    except Error as e:
        print(f"Terjadi kesalahan '{e}'")
    return connection

# Fungsi untuk mengeksekusi query (load)
def execute_query(connection, query, data=None):
    cursor = connection.cursor()
    try:
        if data:
            cursor.execute(query, data)
        else:
            cursor.execute(query)
        connection.commit()
        print("Query berhasil dieksekusi")
    except Error as e:
        print(f"Terjadi kesalahan '{e}'")

# Fungsi untuk memuat data dari CSV ke MySQL (transform, load)
def load_data_to_mysql(connection, csv_file, table_name, columns):
    # Extract: Baca file CSV ke dalam DataFrame
    df = pd.read_csv(csv_file, delimiter=';')
    print("DataFrame dari CSV:")
    print(df.head())

    # Transform: Pilih hanya kolom yang dibutuhkan
    df = df[[col for col in columns if col in df.columns]]

    # Transform: Konversi kolom tertentu ke tipe string jika ada
    string_columns = ['PhoneNumber', 'MobileNumber']
    for col in string_columns:
        if col in df.columns:
            df[col] = df[col].astype(str)

    # Transform: Konversi kolom Waktu ke format datetime MySQL jika ada
    if 'Waktu' in df.columns:
        df['Waktu'] = pd.to_datetime(df['Waktu'], format='%d/%m/%Y %H:%M')
        df['Waktu'] = df['Waktu'].dt.strftime('%Y-%m-%d %H:%M:%S')

    # Transform: Hapus karakter non-numerik dan konversi ke string untuk kolom tertentu
    numeric_columns = ['Jumlah_Transaksi (Rp)', 'Biaya_Admin (Rp)', 'Saldo (Rp)', 'Diskon (%)', 'Tax (Rp)']
    for col in numeric_columns:
        if col in df.columns:
            df[col] = df[col].astype(str).str.replace('[^\d.]', '', regex=True)
            df[col] = df[col].str.replace('.', '')
            df[col] = df[col].str.replace(',', '.')

    # Load: Konversi DataFrame ke list of tuples
    records = df.to_records(index=False)
    records_list = list(records)

    # Load: Buat placeholder untuk data
    placeholders = ', '.join(['%s'] * len(df.columns))

    # Load: Buat query insert
    query = f"INSERT INTO {table_name} (`{'`, `'.join(df.columns)}`) VALUES ({placeholders})"

    # Load: Masukkan data ke dalam tabel
    for record in records_list:
        if not isinstance(record, tuple):
            record = tuple(record)
        try:
            execute_query(connection, query, record)
        except Error as e:
            print(f"Terjadi kesalahan '{e}' untuk record {record}")

# Fungsi utama untuk melakukan proses ETL
def main():
    # Detail koneksi database MySQL
    host_name = "localhost"
    user_name = "root"
    user_password = "Lmjbgcdz33@"
    db_name = "GROUPN_DWH"

    # Buat koneksi MySQL (extract)
    connection = create_connection(host_name, user_name, user_password, db_name)
    
    # Detail file dan tabel
    csv_files = {
        "Nasabah.csv": ("nasabah", ['NasabahID', 'FirstName', 'LastName', 'Address', 'PhoneNumber', 'Status_pengajuan']),
        "aplikasi_data.csv": ("aplikasi", ['AplikasiID', 'Nama_Nasabah', 'Email', 'Pass', 'MobileNumber']),
        "bank_accounts.csv": ("akun_bank", ['AkunID', 'Nama_Nasabah', 'Saldo (Rp)']),
        "histori.csv": ("histori", ['HistoriID', 'AkunID', 'Deskripsi', 'Waktu']),
        "transaksi_dataset.csv": ("transaksi", ['TransaksiID', 'HistoriID', 'AkunID', 'NasabahID', 'AplikasiID', 'Tipe_Transaksi', 'Jumlah_Transaksi (Rp)', 'Waktu', 'Biaya_Admin (Rp)', 'Saldo (Rp)', 'Diskon (%)', 'Tax (Rp)'])
    }
    
    # Muat setiap file CSV ke dalam tabel yang sesuai (transform, load)
    for csv_file, (table_name, columns) in csv_files.items():
        load_data_to_mysql(connection, csv_file, table_name, columns)

    # Tutup koneksi MySQL
    if connection:
        connection.close()
        print("Koneksi Database MySQL selesai")

if __name__ == "__main__":
    main()
